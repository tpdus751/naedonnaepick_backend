package com.naedonnaepick.backend.restaurant.entity;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "restaurant_menus")
public class RestaurantMenu {

    @Id
    private int menuNo;

    private int restaurantNo;

    private String menu;

    private String description;

    private int price;
}