package com.naedonnaepick.backend.restaurant.controller;

@RestController
@RequestMapping("/api/restaurant")
public class RestaurantAPIController {

    private RestaurantService restaurantService;

    @GetMapping("/recommended")
    // 추천 리스트 결과 받아오기
    public List<RestaurantEntity> sendRecommendedRestaurants(
        @RequestParam(name = "location") String location,
        @RequestParam(name = "minPrice") int minPrice,
        @RequestParam(name = "maxPrice") int maxPrice,
        @RequestParam(name = "spicy") int spicy,
        @RequestParam(name = "performPerPrice") int performPerPrice,
        )
}