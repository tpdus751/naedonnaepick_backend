package com.naedonnaepick.backend.restaurant.entity;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "restaurant_tags")
public class RestaurantTags {

    @Id
    private int restaurantNo;

    private float spicy, valueForMoney, kindness, cleanliness, atmosphere, largePortions, tasty, waiting, sweet, salty, savory, freshness, soloDining, trendy, parking;

}