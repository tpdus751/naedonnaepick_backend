package com.naedonnaepick.backend.restaurant.entity;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "restaurants")
public class RestaurantEntity {

    @Id
    private int restaurantNo;

    private String name;

    private String address;

    private float latitude;

    private float longitude;

    private String category;

    private String status;

    private String phoneNumber;

    private RestaurantTags restaurantTags;

    private List<RestaurantMenu> restaurantMenus;

}